new Vue({
  el:'#app',
  data: {
    isLoading: true,
    code: ''
  },
  mounted () {
    this.isLoading = false
    this.code = getURLParam('code')
  },
  methods: {

  }
})